import tkinter
import customtkinter
import random
import string
from PIL import ImageTk, Image

customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("green")

app = customtkinter.CTk()
app.geometry("600x440")
app.title('Login')

def generate_random_password():
    characters = string.ascii_letters + string.digits + string.punctuation
    while True:
        password = ''.join(random.choice(characters) for i in range(8))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password)
                and any(c in string.punctuation for c in password)):
            return password

def save_user_details(username, password, pin, phone_number, initial_amount):
    account_number = ''.join(random.choice(string.digits) for i in range(10))
    with open(f"{username}.txt", "w") as file:
        file.write(f"Username: {username}\n")
        file.write(f"Password: {password}\n")
        file.write(f"Pin: {pin}\n")
        file.write(f"Phone Number: {phone_number}\n")
        file.write(f"Account Number: {account_number}\n")
        file.write(f"Balance: {initial_amount}\n")
        file.write(f"Transactions: \n")
    return account_number

def load_user_details(username):
    try:
        with open(f"{username}.txt", "r") as file:
            details = file.readlines()
        user_info = {}
        for detail in details:
            detail = detail.strip()
            if ": " in detail:  # Ensure the line contains the expected format
                key, value = detail.split(": ", 1)  # Split only at the first occurrence
                user_info[key] = value
            else:
                print(f"Skipping invalid line: {detail}")  # Debugging statement
        return user_info
    except FileNotFoundError:
        return None


def update_balance(username, new_balance):
    lines = []
    with open(f"{username}.txt", "r") as file:
        lines = file.readlines()
    with open(f"{username}.txt", "w") as file:
        for line in lines:
            if line.startswith("Balance"):
                file.write(f"Balance: {new_balance}\n")
            else:
                file.write(line)

def update_transactions(username, transaction):
    lines = []
    with open(f"{username}.txt", "r") as file:
        lines = file.readlines()
    with open(f"{username}.txt", "w") as file:
        for line in lines:
            if line.startswith("Transactions"):
                file.write(f"{line.strip()} {transaction}\n")
            else:
                file.write(line)

def signup_function():
    signup_window = customtkinter.CTkToplevel(app)
    signup_window.geometry("400x600")
    signup_window.title("Sign Up")

    def handle_signup():
        username = entry_username.get()
        password = entry_password.get()
        confirm_password = entry_confirm_password.get()
        pin = entry_pin.get()
        phone_number = entry_phone_number.get()
        initial_amount = entry_initial_amount.get()

        if password != confirm_password:
            customtkinter.CTkLabel(master=signup_window, text="Passwords do not match!").place(x=50, y=500)
            return

        account_number = save_user_details(username, password, pin, phone_number, initial_amount)
        customtkinter.CTkLabel(master=signup_window, text=f"Account created! Your account number is {account_number}").place(x=50, y=500)

    customtkinter.CTkLabel(master=signup_window, text="Sign Up", font=('Century Gothic', 20)).place(x=50, y=25)

    customtkinter.CTkLabel(master=signup_window, text="Username").place(x=50, y=75)
    entry_username = customtkinter.CTkEntry(master=signup_window, width=220)
    entry_username.place(x=50, y=100)

    customtkinter.CTkLabel(master=signup_window, text="Password").place(x=50, y=150)
    entry_password = customtkinter.CTkEntry(master=signup_window, width=220, show="*")
    entry_password.place(x=50, y=175)

    customtkinter.CTkLabel(master=signup_window, text="Confirm Password").place(x=50, y=225)
    entry_confirm_password = customtkinter.CTkEntry(master=signup_window, width=220, show="*")
    entry_confirm_password.place(x=50, y=250)

    customtkinter.CTkLabel(master=signup_window, text="Pin").place(x=50, y=300)
    entry_pin = customtkinter.CTkEntry(master=signup_window, width=220)
    entry_pin.place(x=50, y=325)

    customtkinter.CTkLabel(master=signup_window, text="Phone Number").place(x=50, y=375)
    entry_phone_number = customtkinter.CTkEntry(master=signup_window, width=220)
    entry_phone_number.place(x=50, y=400)

    customtkinter.CTkLabel(master=signup_window, text="Initial Amount (R)").place(x=50, y=450)
    entry_initial_amount = customtkinter.CTkEntry(master=signup_window, width=220)
    entry_initial_amount.place(x=50, y=475)

    customtkinter.CTkButton(master=signup_window, text="Sign Up", command=handle_signup).place(x=50, y=525)

    customtkinter.CTkButton(master=signup_window, text="Generate Random Password", command=lambda: entry_password.insert(0, generate_random_password())).place(x=50, y=550)

def login_function():
    username = entry_username.get()
    password = entry_password.get()

    user_info = load_user_details(username)
    print(f"Loaded user info: {user_info}")  # Debugging statement
    if user_info and user_info["Password"] == password:
        app.destroy()
        main_screen(username, user_info)
    else:
        customtkinter.CTkLabel(master=frame, text="Invalid username or password", font=('Century Gothic', 12)).place(x=50, y=270)

def main_screen(username, user_info):
    main_app = customtkinter.CTk()
    main_app.geometry("1280x720")
    main_app.title('Welcome to WizzBank')

    customtkinter.CTkLabel(master=main_app, text=f"Welcome, {username}", font=('Century Gothic', 20)).place(x=50, y=25)
    customtkinter.CTkLabel(master=main_app, text=f"Account Number: {user_info['Account Number']}", font=('Century Gothic', 20)).place(x=50, y=75)
    customtkinter.CTkLabel(master=main_app, text=f"Balance: R{user_info['Balance']}", font=('Century Gothic', 20)).place(x=50, y=125)

    def handle_withdrawal():
        withdrawal_window = customtkinter.CTkToplevel(main_app)
        withdrawal_window.geometry("400x400")
        withdrawal_window.title("Withdraw")

        def process_withdrawal():
            amount = float(entry_amount.get())
            new_balance = float(user_info['Balance']) - amount
            update_balance(username, new_balance)
            update_transactions(username, f"Withdrawn: R{amount}")
            customtkinter.CTkLabel(master=withdrawal_window, text="Withdrawal Successful").place(x=50, y=200)

        customtkinter.CTkLabel(master=withdrawal_window, text=f"Name: {username}", font=('Century Gothic', 20)).place(x=50, y=25)
        customtkinter.CTkLabel(master=withdrawal_window, text=f"Available Balance: R{user_info['Balance']}", font=('Century Gothic', 20)).place(x=50, y=75)
        customtkinter.CTkLabel(master=withdrawal_window, text="Amount to Withdraw").place(x=50, y=125)
        entry_amount = customtkinter.CTkEntry(master=withdrawal_window, width=220)
        entry_amount.place(x=50, y=150)
        customtkinter.CTkButton(master=withdrawal_window, text="Withdraw", command=process_withdrawal).place(x=50, y=200)
        customtkinter.CTkButton(master=withdrawal_window, text="Back to Banking", command=withdrawal_window.destroy).place(x=50, y=250)

    def handle_transfer():
        transfer_window = customtkinter.CTkToplevel(main_app)
        transfer_window.geometry("400x600")
        transfer_window.title("Transfer")

        def process_transfer():
            recipient_name = entry_recipient_name.get()
            recipient_account = entry_recipient_account.get()
            amount = float(entry_amount.get())
            if recipient_name == username:
                customtkinter.CTkLabel(master=transfer_window, text="Cannot transfer to self").place(x=50, y=400)
                return

            recipient_info = load_user_details(recipient_name)
            if recipient_info and recipient_info["Account Number"] == recipient_account:
                new_balance = float(user_info['Balance']) - amount
                update_balance(username, new_balance)
                update_transactions(username, f"Transferred: R{amount} to {recipient_name}")
                recipient_new_balance = float(recipient_info['Balance']) + amount
                update_balance(recipient_name, recipient_new_balance)
                update_transactions(recipient_name, f"Received: R{amount} from {username}")
                customtkinter.CTkLabel(master=transfer_window, text="Transfer Successful").place(x=50, y=450)
            else:
                customtkinter.CTkLabel(master=transfer_window, text="Invalid recipient details").place(x=50, y=400)

        customtkinter.CTkLabel(master=transfer_window, text="Recipient Name").place(x=50, y=25)
        entry_recipient_name = customtkinter.CTkEntry(master=transfer_window, width=220)
        entry_recipient_name.place(x=50, y=50)

        customtkinter.CTkLabel(master=transfer_window, text="Recipient Account Number").place(x=50, y=100)
        entry_recipient_account = customtkinter.CTkEntry(master=transfer_window, width=220)
        entry_recipient_account.place(x=50, y=125)

        customtkinter.CTkLabel(master=transfer_window, text="Amount to Transfer (R)").place(x=50, y=175)
        entry_amount = customtkinter.CTkEntry(master=transfer_window, width=220)
        entry_amount.place(x=50, y=200)

        customtkinter.CTkButton(master=transfer_window, text="Transfer", command=process_transfer).place(x=50, y=250)
        customtkinter.CTkButton(master=transfer_window, text="Back to Banking", command=transfer_window.destroy).place(x=50, y=300)

    def handle_statement():
        statement_window = customtkinter.CTkToplevel(main_app)
        statement_window.geometry("400x600")
        statement_window.title("Statement")

        customtkinter.CTkLabel(master=statement_window, text="Transaction History", font=('Century Gothic', 20)).place(x=50, y=25)
        transactions = [line.strip() for line in load_user_details(username)["Transactions"].split("Transactions: ")[1].split()]
        for i, transaction in enumerate(transactions):
            customtkinter.CTkLabel(master=statement_window, text=transaction).place(x=50, y=75 + 25*i)

        customtkinter.CTkButton(master=statement_window, text="Sign Out", command=lambda: main_app.destroy()).place(x=50, y=500)

    customtkinter.CTkButton(master=main_app, text="Withdraw", command=handle_withdrawal).place(x=50, y=200)
    customtkinter.CTkButton(master=main_app, text="Transfer", command=handle_transfer).place(x=50, y=250)
    customtkinter.CTkButton(master=main_app, text="Statement", command=handle_statement).place(x=50, y=300)
    customtkinter.CTkButton(master=main_app, text="Logout", command=lambda: main_app.destroy()).place(x=50, y=350)
    main_app.mainloop()

img1 = ImageTk.PhotoImage(Image.open("pattern.png"))
l1 = customtkinter.CTkLabel(master=app, image=img1)
l1.pack()

frame = customtkinter.CTkFrame(master=l1, width=320, height=360, corner_radius=15)
frame.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)

customtkinter.CTkLabel(master=frame, text="Log into your Account", font=('Century Gothic', 20)).place(x=50, y=45)

entry_username = customtkinter.CTkEntry(master=frame, width=220, placeholder_text='Username')
entry_username.place(x=50, y=110)

entry_password = customtkinter.CTkEntry(master=frame, width=220, placeholder_text='Password', show="*")
entry_password.place(x=50, y=165)

customtkinter.CTkLabel(master=frame, text="Forget password?", font=('Century Gothic', 12)).place(x=155, y=195)

customtkinter.CTkButton(master=frame, width=220, text="Login", command=login_function, corner_radius=6).place(x=50, y=240)
customtkinter.CTkButton(master=frame, width=220, text="Sign Up", command=signup_function, corner_radius=6).place(x=50, y=300)

app.mainloop()
